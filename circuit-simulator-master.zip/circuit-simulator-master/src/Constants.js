export const GROUND_NODE = 0;
