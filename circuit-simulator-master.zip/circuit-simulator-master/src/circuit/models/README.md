# Models

All models should be imported using [src/ui/diagram/components/models](.) so they have a `typeID`.
