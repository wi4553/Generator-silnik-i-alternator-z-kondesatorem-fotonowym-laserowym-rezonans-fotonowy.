# Views

All views should be imported using [src/ui/diagram/components](.) so they have a `typeID`.
