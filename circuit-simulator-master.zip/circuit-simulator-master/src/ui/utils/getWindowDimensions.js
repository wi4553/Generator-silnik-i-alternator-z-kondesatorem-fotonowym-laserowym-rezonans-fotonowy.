export default function getWindowDimensions() {
  return {
    width: window.innerWidth,
    height: window.innerHeight
  };
}
