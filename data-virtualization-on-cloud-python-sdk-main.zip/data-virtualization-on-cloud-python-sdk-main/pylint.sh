#!/bin/bash

python3 -m pylint ibm_data_virtualization_on_cloud test --exit-zero
